<?php
/**
 * Plugin Name: WooCommerce PayCEC Gateway
 * Plugin URI: https://developer.paycec.com/download-source
 * Description: Payment Services Solutions
 * Author: PayCec
 * Author URI: https://developer.paycec.com/
 * Version: 2.1.1
 * Text Domain: wc-paycec-gateway
 * Domain Path: /i18n/languages/
 * WC tested up to: 3.2
 * WC requires at least: 2.6
 *
 * Copyright: (c) 2017-2018 , Inc. () and WooCommerce
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package   WC-PayCEC-Gateway
 * @author
 * @category  Admin
 * @copyright Copyright (c) 2017-2018, , Inc. and WooCommerce
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 *
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

function wc_wpc_add_to_gateways($gateways)
{
    $gateways[] = 'WC_WPC_Gateway';
    return $gateways;
}

add_filter('woocommerce_payment_gateways', 'wc_wpc_add_to_gateways');

function wc_wpc_gateway_plugin_links($links)
{
    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=wpc_gateway') . '">' . __('Configure', 'paycec-gateway') . '</a>'
    );
    return array_merge($plugin_links, $links);
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wc_wpc_gateway_plugin_links');

add_action('plugins_loaded', 'wc_wpc_gateway_init', 11);

function wc_wpc_gateway_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_WPC_Gateway extends WC_Payment_Gateway
    {
        private $merchantName, $merchantSecretKey;
        public $sandbox, $tokenUrl, $detailsUrl, $webScreenUrl, $instructions, $msg;

        public function __construct()
        {
            $this->id = 'wpc_gateway';
            $this->icon = apply_filters('woocommerce_mpowerpayment_icon', plugins_url('logo.svg', __FILE__));
            $this->has_fields = false;
            $this->method_title = __('PayCEC Gateway');
            $this->method_description = __('Payment Services Solutions');

            $this->merchantName = $this->get_option('merchantName');
            $this->merchantSecretKey = $this->get_option('merchantSecretKey');

            $this->sandbox = $this->get_option('sandbox');

            // Setting environment : test mode or live mode (default)
            if ($this->get_option('testmode') == "yes") {
                $this->tokenUrl = 'https://securetest.paycec.com/redirect-service/request-token';
                $this->detailsUrl = 'https://securetest.paycec.com/redirect-service/purchase-details';
                $this->webScreenUrl = 'https://securetest.paycec.com/redirect-service/webscreen?token=';
            } else {
                $this->tokenUrl = 'https://secure.paycec.com/redirect-service/request-token';
                $this->detailsUrl = 'https://secure.paycec.com/redirect-service/purchase-details';
                $this->webScreenUrl = 'https://secure.paycec.com/redirect-service/webscreen?token=';
            }
            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            $this->msg['message'] = "";
            $this->msg['class'] = "";

            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->instructions = $this->get_option('instructions', $this->description);

            if (isset($_REQUEST["token"]) && $_REQUEST["token"] <> "") {
                $this->check_wpc_response(trim($_REQUEST["token"]));
            }

            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array(&$this, 'process_admin_options'));
            }
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'paycec-gateway'),
                    'type' => 'checkbox',
                    'label' => __('Enable PayCEC Gateway', 'paycec-gateway'),
                    'default' => 'yes'
                ),

                'testmode' => array(
                    'title' => __('Test Mode', 'paycec-gateway'),
                    'type' => 'checkbox',
                    'description' => sprintf(__('PayCEC Test Mode can be used to test payments. Sign up for a <a href="%s">developer account</a>.', 'paycec-gateway'), 'https://developer.paycec.com'),
                ),

                'merchantName' => array(
                    'title' => __('Merchant’s ID (MerID)', 'mpower'),
                    'type' => 'text',
                    'placeholder' => 'paycec_example',
                ),

                'merchantSecretKey' => array(
                    'title' => __('Merchant Secret Key', 'mpower'),
                    'type' => 'text',
                    'placeholder' => 'paycec_secret_key',
                ),

                'title' => array(
                    'title' => __('Title', 'paycec-gateway'),
                    'type' => 'text',
                    'description' => __('This controls the title for the payment method the customer sees during checkout.', 'paycec-gateway'),
                    'default' => __('PayCEC Payment', 'paycec-gateway'),
                    'desc_tip' => true,
                ),

                'description' => array(
                    'title' => __('Description', 'paycec-gateway'),
                    'type' => 'textarea',
                    'description' => __('Payment method description that the customer will see on your checkout.', 'paycec-gateway'),
                    'default' => __('PayCec; you can pay with your credit card.', 'paycec-gateway'),
                    'desc_tip' => true,
                ),
            );
        }

        public function admin_options()
        {
            echo '<h3>' . __('PayCEC Payment Gateway', 'paycec-gateway') . '</h3>';
            echo '<p>' . __('Allow customers to conveniently checkout directly with PayCEC.') . '</p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        function check_wpc_response($token)
        {
            global $woocommerce;
            $msg['class'] = 'error';
            $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";

            $wc_order_id = wc_get_order_id_by_order_key($_GET['key']);
            $order = new WC_Order($wc_order_id);

            $redirect_url = $order->get_cancel_order_url();
            if (isset($token)) {
                try {
                    $params = array(
                        'merchantName' => $this->merchantName,
                        'merchantSecretKey' => $this->merchantSecretKey,
                        'token' => $token,
                    );

                    $params['sig'] = generateSignatureWpc($this->detailsUrl, $params, $this->merchantSecretKey);

                    $errorCode = 0;
                    $errorMessage = '';
                    $reply = callWpc($this->detailsUrl, $params, $errorCode, $errorMessage);

                    if ($reply != null && $reply->isSuccessful == 'true') {
                        $mes = 'Successfully charged!
                            Timestamp: ' . $reply->timestamp . '
                            Transaction ID: ' . $reply->transactionId . '
                            Token: ' . $token . '
                            Request ID: ' . $reply->requestId . '
                            Description: ' . $reply->referenceCode . '
                        ';
                        $msg['message'] = 'Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.';
                        $msg['class'] = 'success';
                        $order->add_order_note($mes);
                        $order->payment_complete($reply->transactionId);
                        //$order->update_status('completed');
                        $order->update_status('processing');
                        //$order->reduce_order_stock();
                        $woocommerce->cart->empty_cart();
                        $redirect_url = $this->get_return_url($order);
                    } else {
                        //Error handling
                        $msg['class'] = 'error';
                        if ($reply) {
                            $order->update_status('failed');
                            $mes = 'We\'ve got some errors retrieving from PayCEC service.
                                 </br> - Error Code: ' . $reply->errorCode . '</br>
                                  - Error Message 1: ' . $reply->errorMessage;
                            if (isset($reply->message)) {
                                $mes .= '</br>- Error Message 2: ' . $reply->message;
                            }
                            if (isset($reply->errorField)) {
                                $mes .= '</br>- Error Field: ' . $reply->errorField;
                            }
                            $msg['message'] = $mes;
                            $order->add_order_note($mes);
                            wc_add_notice($mes, 'error');
                        } else if (!empty($errorMessage)) {
                            $mes = 'We\'ve got some errors when connecting to Secure PayCEC service.
                                </br> - Error Code: ' . $errorCode . '</br>
                                 - Error Message: ' . $errorMessage;
                            $msg['message'] = $mes;
                            $order->add_order_note($mes);
                            wc_add_notice($mes, 'error');
                        }
                    }
                } catch (Exception $e) {
                    $order->update_status('failed');
                    $order->add_order_note('Error: ' . $e->getMessage());
                    $msg['class'] = 'error';
                    $msg['message'] = 'Error: ' . $e->getMessage();
                }
            } else {
                $msg['class'] = 'error';
                $msg['message'] = 'Missing token.';
            }

            if (function_exists('wc_add_notice')) {
                wc_add_notice($msg['message'], $msg['class']);
            } else {
                if ($msg['class'] == 'success') {
                    $woocommerce->add_message($msg['message']);
                } else {
                    $woocommerce->add_error($msg['message']);
                }
                $woocommerce->set_messages();
            }

            wp_redirect($redirect_url);
            exit;
        }

        public function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            $description = get_bloginfo( 'name' ).' Order #'.$order_id;
            $params_cart = array();
            $i = 0;
            foreach ($order->get_items() as $item) {
                $params_cart["item_{$i}_id"] = $item->get_product_id();
                $params_cart["item_{$i}_amt"] = $item->get_total() / $item->get_quantity();
                $params_cart["item_{$i}_name"] = $item->get_name();
                $params_cart["item_{$i}_qty"] = $item->get_quantity();
                $i++;
            }
            $params = array(
                'merchantName'          => $this->merchantName,
                'merchantSecretKey'     => $this->merchantSecretKey,
                'merchantToken'         => time(),
                'merchantReferenceCode' => $description,
                'amount'                => $order->get_total(),
                'currencyCode'          => get_woocommerce_currency(),
                'returnUrl'             => $this->get_return_url($order),
                'cancelUrl'             => $order->get_cancel_order_url(),
                'shippingTotal'         => $order->get_shipping_total(),
                'billing'               => serialize(array(
                    'first_name'    => $order->get_billing_first_name(),
                    'last_name'     => $order->get_billing_last_name(),
                    'address'       => $order->get_billing_address_1(),
                    'country'       => $order->get_billing_country(),
                    'city'          => $order->get_billing_city(),
                    'state'         => $order->get_billing_state(),
                    'postal'        => $order->get_billing_postcode(),
                    'phone'         => $order->get_billing_phone(),
                    'email'         => $order->get_billing_email(),
                ))
            );
            $params = array_merge($params, $params_cart);
            $params['sig'] = generateSignatureWpc($this->tokenUrl, $params, $this->merchantSecretKey);

            $errorCode = 0;
            $errorMessage = '';
            $reply = callWpc($this->tokenUrl, $params, $errorCode, $errorMessage);

            if ($reply != null && $reply->isSuccessful == 'true') {
                WC()->session->set('wpc_oder_id', $order_id);
                return array(
                    'result' => 'success',
                    'redirect' => $this->webScreenUrl . $reply->token,
                );
            } else {
                if ($reply) {
                    $mes = 'We\'ve got some errors retrieving from PayCEC service.
                    </br> - Error Code: ' . $reply->errorCode . '</br>
                     - Error Message 1: ' . $reply->errorMessage;
                    if (isset($reply->message)) {
                        $mes .= '</br>- Error Message 2: ' . $reply->message;
                    }
                    if (isset($reply->errorField)) {
                        $mes .= '</br>- Error Field: ' . $reply->errorField;
                    }
                    $order->add_order_note($mes);
                    wc_add_notice($mes, 'error');
                } else if (!empty($errorMessage)) {
                    $mes = 'We\'ve got some errors when connecting to Secure PayCEC service.
                    </br> - Error Code: ' . $errorCode . '</br>
                     - Error Message: ' . $errorMessage;
                    $order->add_order_note($mes);
                    wc_add_notice($mes, 'error');
                }

                return array(
                    'result' => 'fail',
                    'redirect' => $order->get_cancel_order_url(),
                );
            }
        }

        function get_pages($title = false, $indent = true)
        {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title)
                $page_list[] = $title;
            foreach ($wp_pages as $page) {
                $prefix = '';
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }
    }


    function generateSignatureWpc($endpoint, $params, $secretKey)
    {
        ksort($params);
        $sig = $endpoint . '?' . http_build_query($params);
        return hash_hmac('sha512', $sig, $secretKey, false);
    }

    function callWpc($endpoint, $params, &$errorNo = 0, &$errorMessage = '')
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));

        $resultString = curl_exec($ch);

        if (curl_errno($ch)) {
            $errorNo = curl_errno($ch);
            $errorMessage = curl_error($ch);
            curl_close($ch);

            return null;
        }

        curl_close($ch);
        return json_decode($resultString);
    }
}