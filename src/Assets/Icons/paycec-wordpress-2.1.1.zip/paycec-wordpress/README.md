# WORLDPAYMENTSCORP
## Wordpress WooCommerce Plugin (Version 2.1)

* Website: https://www.paycec.com
* Developer website: https://developer.paycec.com
* Email: tech@paycec.com
* Skype: tech@paycec.com


1.0 - 2017-10-27
Init version.

1.1 - 2017-12-12
Rename Merchant Name by Merchant’s ID (MerID)

1.2 - 2018-1-2
Fix bugs

1.3 - 2018-2-7
Chang logo PayCEC Plugin

2.0 - 2018-05-24
Change API endpoint domain to secure.paycec.com (LIVE) and securetest.paycec.com (TEST).

2.1 - 2023-06-25
Update UX, auto fill billing info and support Papmall power